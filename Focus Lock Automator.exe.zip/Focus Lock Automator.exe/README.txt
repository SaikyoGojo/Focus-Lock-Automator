Focus-Lock Automator v6.0

Quick Start: Using the Executable

1.  **Download:** Get the latest `Focus_Lock_Automator_v6.0.zip` package from the **SourceForge** downloads page.
2.  **Run:** Execute `Focus Lock Automator.exe` directly.

Core Usage Guide

1.  **Target Lock:** Open your game/app. In the Automator GUI, click **Refresh** and select the window title (e.g., `Roblox`).
2.  **Customization:** Go to the **Custom Mode** tab to set your actions:
    * Set **Min/Max Delay** (time between actions).
    * Enter **Tap Keys** (e.g., `w, s, 1, 2`).
    * Enter **Long Press Keys** (keys to be held down briefly).
    * Use the **Priority Slider** to control the chance of a long press vs. a tap.
3.  **Run:** Click **Save** (in the Profiles tab) then click **Start**. The tool will automatically send inputs to the locked window.

For Developers (Running from Source)

To modify and run the Python source code:

1.  **Clone the Repository:** Get the code from GitHub.
2.  **Install Dependencies:** Run `pip install -r requirements.txt`.
3.  **Run:** Execute `python "Focus Lock Automator.py"`.

License

This project is released under the **MIT License**.